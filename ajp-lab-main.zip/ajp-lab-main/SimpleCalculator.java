import javax.swing.*;
import java.awt.event.*;

public class SimpleCalculator extends JFrame implements ActionListener {
    JTextField num1Field, num2Field, resultField;
    JButton addBtn, subBtn, mulBtn, divBtn;

    public SimpleCalculator() {
    
        setTitle("Basic Arithmetic Calculator");
        setLayout(null);
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      
        JLabel num1Label = new JLabel("Number 1:");
        num1Label.setBounds(20, 20, 80, 25);
        add(num1Label);

        num1Field = new JTextField();
        num1Field.setBounds(100, 20, 200, 25);
        add(num1Field);

        JLabel num2Label = new JLabel("Number 2:");
        num2Label.setBounds(20, 60, 80, 25);
        add(num2Label);

        num2Field = new JTextField();
        num2Field.setBounds(100, 60, 200, 25);
        add(num2Field);

        addBtn = new JButton("+");
        addBtn.setBounds(20, 100, 50, 30);
        addBtn.addActionListener(this);
        add(addBtn);

        subBtn = new JButton("-");
        subBtn.setBounds(80, 100, 50, 30);
        subBtn.addActionListener(this);
        add(subBtn);

        mulBtn = new JButton("*");
        mulBtn.setBounds(140, 100, 50, 30);
        mulBtn.addActionListener(this);
        add(mulBtn);

        divBtn = new JButton("/");
        divBtn.setBounds(200, 100, 50, 30);
        divBtn.addActionListener(this);
        add(divBtn);

        JLabel resultLabel = new JLabel("Result:");
        resultLabel.setBounds(20, 150, 80, 25);
        add(resultLabel);

        resultField = new JTextField();
        resultField.setBounds(100, 150, 200, 25);
        resultField.setEditable(false);
        add(resultField);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        try {
            double num1 = Double.parseDouble(num1Field.getText());
            double num2 = Double.parseDouble(num2Field.getText());
            double result = 0;

            if (e.getSource() == addBtn) {
                result = num1 + num2;
            } else if (e.getSource() == subBtn) {
                result = num1 - num2;
            } else if (e.getSource() == mulBtn) {
                result = num1 * num2;
            } else if (e.getSource() == divBtn) {
                if (num2 == 0) {
                    JOptionPane.showMessageDialog(this, "Cannot divide by zero");
                    return;
                }
                result = num1 / num2;
            }

            resultField.setText(String.valueOf(result));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers");
        }
    }

    public static void main(String[] args) {
        new SimpleCalculator();
    }
}
