import javax.swing.*;
import java.awt.*;

class TwoFramesExample {
    public static void main(String args[]) {
        // First Frame
        JFrame frame1 = new JFrame("First Frame");
        frame1.setSize(400, 300);
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.getContentPane().setBackground(Color.pink);
        frame1.setLayout(null);

        JLabel label1 = new JLabel("This is the first frame");
        label1.setBounds(50, 100, 300, 30);
        frame1.add(label1);

        frame1.setVisible(true);

        // Second Frame
        JFrame frame2 = new JFrame("Second Frame");
        frame2.setSize(400, 300);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.getContentPane().setBackground(Color.cyan);
        frame2.setLayout(null);

        JLabel label2 = new JLabel("This is the second frame");
        label2.setBounds(50, 100, 300, 30);
        frame2.add(label2);

        frame2.setVisible(true);
    }
}
