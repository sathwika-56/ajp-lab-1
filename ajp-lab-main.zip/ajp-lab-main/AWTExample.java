import java.awt.*;
import java.awt.event.*;
public class AWTExample extends Frame implements ActionListener{
Button b=new Button("Click me!jjjj");

AWTExample(){
b.setBounds(50,100,80,30);
b.addActionListener(this);
 b.setBackground(Color.GREEN);
add(b);
setSize(300,300);
setBackground(Color.BLUE);
setLayout(null);
setVisible(true);}

public void actionPerformed(ActionEvent e){
System.out.println("Button clicked!");
}
public static void main(String args[]){
new AWTExample();}}