import javax.swing.*;
import java.awt.event.*;

public class WindowEventDemo extends JFrame implements WindowListener {

    public WindowEventDemo() {
        setTitle("Window Event Demo");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); // We'll handle close manually
        addWindowListener(this);

        JLabel label = new JLabel("Perform window actions and check console!", SwingConstants.CENTER);
        add(label);

        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    // Implementing all WindowListener methods
    public void windowOpened(WindowEvent e) {
        System.out.println("Window opened.");
    }

    public void windowClosing(WindowEvent e) {
        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to close?",
                "Confirm Exit", JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            System.out.println("Window closing...");
            dispose(); // Close the window
            System.exit(0); // Exit the app
        } else {
            System.out.println("Window close cancelled.");
        }
    }

    public void windowClosed(WindowEvent e) {
        System.out.println("Window closed.");
    }

    public void windowIconified(WindowEvent e) {
        System.out.println("Window minimized.");
    }

    public void windowDeiconified(WindowEvent e) {
        System.out.println("Window restored.");
    }

    public void windowActivated(WindowEvent e) {
        System.out.println("Window activated.");
    }

    public void windowDeactivated(WindowEvent e) {
        System.out.println("Window deactivated.");
    }

    public static void main(String[] args) {
        new WindowEventDemo();
    }
}
