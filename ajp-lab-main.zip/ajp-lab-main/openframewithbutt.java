import javax.swing.*;
import java.awt.event.*;

public class openframewithbutt extends JFrame {

    public openframewithbutt() {
        setTitle("Main Frame");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create buttons
        JButton openFrame1Button = new JButton("Open Frame 1");
        JButton openFrame2Button = new JButton("Open Frame 2");

        // Add action listeners
        openFrame1Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Frame1().setVisible(true);
            }
        });

        openFrame2Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Frame2().setVisible(true);
            }
        });

        // Layout buttons vertically
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(openFrame1Button);
        panel.add(openFrame2Button);

        add(panel);
    }

    // Frame1 class
    class Frame1 extends JFrame {
        public Frame1() {
            setTitle("Frame 1");
            setSize(200, 150);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            add(new JLabel("This is Frame 1", SwingConstants.CENTER));
        }
    }

    // Frame2 class
    class Frame2 extends JFrame {
        public Frame2() {
            setTitle("Frame 2");
            setSize(200, 150);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            add(new JLabel("This is Frame 2", SwingConstants.CENTER));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new openframewithbutt().setVisible(true);
            }
        });
    }
}
=======
import javax.swing.*;
import java.awt.event.*;

public class openframewithbutt extends JFrame {

    public openframewithbutt() {
        setTitle("Main Frame");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create buttons
        JButton openFrame1Button = new JButton("Open Frame 1");
        JButton openFrame2Button = new JButton("Open Frame 2");

        // Add action listeners
        openFrame1Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Frame1().setVisible(true);
            }
        });

        openFrame2Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Frame2().setVisible(true);
            }
        });

        // Layout buttons vertically
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(openFrame1Button);
        panel.add(openFrame2Button);

        add(panel);
    }

    // Frame1 class
    class Frame1 extends JFrame {
        public Frame1() {
            setTitle("Frame 1");
            setSize(200, 150);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            add(new JLabel("This is Frame 1", SwingConstants.CENTER));
        }
    }

    // Frame2 class
    class Frame2 extends JFrame {
        public Frame2() {
            setTitle("Frame 2");
            setSize(200, 150);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            add(new JLabel("This is Frame 2", SwingConstants.CENTER));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new openframewithbutt().setVisible(true);
            }
        });
    }
}
