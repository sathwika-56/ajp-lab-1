import java.util.*;
class hii{
 void hii(){
System.out.println("HI");
}}

class hello extends hii {
 void hello(){
System.out.println("HELLO");}}

class inheritance{
public static void main(String args[]){
hello ki=new hello();
ki.hii();
ki.hello();
}}
