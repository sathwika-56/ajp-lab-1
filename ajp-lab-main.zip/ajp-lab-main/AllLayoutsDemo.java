import javax.swing.*;
import java.awt.*;

public class AllLayoutsDemo extends JFrame {

    public AllLayoutsDemo() {
        setTitle("Layout Managers Demo");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        // FlowLayout tab
        JPanel flowPanel = new JPanel(new FlowLayout());
        for (int i = 1; i <= 5; i++) {
            flowPanel.add(new JButton("Button " + i));
        }
        tabbedPane.addTab("FlowLayout", flowPanel);

        // BorderLayout tab
        JPanel borderPanel = new JPanel(new BorderLayout());
        borderPanel.add(new JButton("North"), BorderLayout.NORTH);
        borderPanel.add(new JButton("South"), BorderLayout.SOUTH);
        borderPanel.add(new JButton("East"), BorderLayout.EAST);
        borderPanel.add(new JButton("West"), BorderLayout.WEST);
        borderPanel.add(new JButton("Center"), BorderLayout.CENTER);
        tabbedPane.addTab("BorderLayout", borderPanel);

        // GridLayout tab
        JPanel gridPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        for (int i = 1; i <= 6; i++) {
            gridPanel.add(new JButton("Button " + i));
        }
        tabbedPane.addTab("GridLayout", gridPanel);

        // Null Layout tab
        JPanel nullPanel = new JPanel(null); // null layout
        JButton b1 = new JButton("Button 1");
        b1.setBounds(50, 50, 100, 30);
        JButton b2 = new JButton("Button 2");
        b2.setBounds(200, 100, 100, 30);
        nullPanel.add(b1);
        nullPanel.add(b2);
        tabbedPane.addTab("Null Layout", nullPanel);

        add(tabbedPane);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AllLayoutsDemo().setVisible(true);
            }
        });
    }
}
