import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;

public class SimpleGreeting extends JFrame {
    private JLabel greetingLabel;
    private JButton showGreetingButton;

    public SimpleGreeting() {
        // Set up the frame
        setTitle("Time-Based Greeting");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        // Initialize components
        greetingLabel = new JLabel("Click the button for greeting!");
        showGreetingButton = new JButton("Show Greeting");

        // Add components to frame
        add(greetingLabel);
        add(showGreetingButton);

        // Button action listener
        showGreetingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get current hour using Calendar
                int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
                
                // Determine greeting based on time
                String greeting;
                if (hour >= 5 && hour < 12) {
                    greeting = "Good Morning!";
                } else if (hour >= 12 && hour < 17) {
                    greeting = "Good Afternoon!";
                } else {
                    greeting = "Good Evening!";
                }
                
                // Update label with greeting
                greetingLabel.setText(greeting);
            }
        });
    }

    public static void main(String[] args) {
        // Create and show the frame
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SimpleGreeting().setVisible(true);
            }
        });
    }
}