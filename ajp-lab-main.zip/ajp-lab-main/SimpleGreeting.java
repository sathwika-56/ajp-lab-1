import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;

public class SimpleGreeting extends JFrame {
    private JLabel greetingLabel;
    private JButton showGreetingButton;

    public SimpleGreeting() {
     
        setTitle("Time-Based Greeting");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

     
        greetingLabel = new JLabel("Click the button for greeting!");
        showGreetingButton = new JButton("Show Greeting");

      
        add(greetingLabel);
        add(showGreetingButton);

     
        showGreetingButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                
                int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
                
                
                String greeting;
                if (hour >= 5 && hour < 12) {
                    greeting = "Good Morning!";
                } else if (hour >= 12 && hour < 17) {
                    greeting = "Good Afternoon!";
                } else {
                    greeting = "Good Evening!";
                }
                
               
                greetingLabel.setText(greeting);
            }
        });
    }

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(new Runnable() {
          
            public void run() {
                new SimpleGreeting().setVisible(true);
            }
        });
    }
}