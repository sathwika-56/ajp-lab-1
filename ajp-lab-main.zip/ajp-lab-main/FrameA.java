class FrameA extends JFrame implements ActionListener {

    private JButton backButton;

    public FrameA() {

      setTitle("Frame A");

      setSize(300, 150);

      setLayout(new FlowLayout());

      add(new JLabel("This is Frame A"));

      backButton = new JButton("Back to Main Frame");

      backButton.addActionListener(this);

      add(backButton);

      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      setVisible(true);

    }

    public void actionPerformed(ActionEvent e) {

      dispose(); // Close Frame A

      new MainFrameApp(); // Reopen Main Frame

    }

  }

